<!DOCTYPE html>
<html>
<head>
    <title>Daftar Menu Cafe</title>
    <style>
        table {
            border-collapse: collapse;
            width: 70%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px 12px;
            text-align: left;
        }
        h2 {
            font-family: Arial, sans-serif;
        }
    </style>
</head>
<body>
    <h2>Daftar Menu Cafe</h2>
    <table>
        <thead>
            <tr>
                <th>Menu</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($menu->name); ?></td>
                    <td><?php echo e($menu->category); ?></td>
                    <td><?php echo e($menu->stock); ?></td>
                    <td>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        <thead>
            <tr>
                <th>Caffe Latte</th>
                <th>Minuman</th>
                <th>18</th>
                <th>Rp. 18.000</th>
            </tr>   
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($menu->name); ?></td>
                    <td><?php echo e($menu->category); ?></td>
                    <td><?php echo e($menu->stock); ?></td>
                    <td>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    

        <thead>
            <tr>
                <th>Matcha</th>
                <th>Minuman</th>
                <th>100</th>
                <th>Rp. 29.000</th>
            </tr>   
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($menu->name); ?></td>
                    <td><?php echo e($menu->category); ?></td>
                    <td><?php echo e($menu->stock); ?></td>
                    <td>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        <thead>
            <tr>
                <th>Fried Rice</th>
                <th>Makanan</th>
                <th>120</th>
                <th>Rp. 20.000</th>
            </tr>   
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($menu->name); ?></td>
                    <td><?php echo e($menu->category); ?></td>
                    <td><?php echo e($menu->stock); ?></td>
                    <td>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        <thead>
            <tr>
                <th>Chicken Wings</th>
                <th>Makanan</th>
                <th>80</th>
                <th>Rp. 14.000</th>
            </tr>   
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($menu->name); ?></td>
                    <td><?php echo e($menu->category); ?></td>
                    <td><?php echo e($menu->stock); ?></td>
                    <td>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
</body>
</html>
<?php /**PATH D:\cafe-app\resources\views/cafe.blade.php ENDPATH**/ ?>